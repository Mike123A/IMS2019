<?php  
$conexion = new mysqli("localhost","imedical_root","&aFPdS21t-oz","imedical_bd_ims");
	if ($conexion) {
		// echo "SI";
	}
	else{
		echo "NO";
	}
?>